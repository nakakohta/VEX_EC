# VEXのECサイト

### 教材URL
[Udemy](https://kbc.udemy.com/course/laravel9/learn/lecture/31677172#content)
